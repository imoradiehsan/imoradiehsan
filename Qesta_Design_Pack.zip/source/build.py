# Builds the single-file desktop and mobile HTML from app.html + loans.js + assets.js
h=open('app.html').read()
def bundle(x):return x.replace('<script src="loans.js"></script>','<script>'+open('loans.js').read()+'</script>').replace('<script src="assets.js"></script>','<script>'+open('assets.js').read()+'</script>')
v=bundle(h);open('../Qesta_Design_Desktop.html','w').write(v)
mob=open('../Qesta_Design_Mobile.html').read();mcss=mob[mob.index('<style id="mobile">'):mob.index('</head>')]
open('../Qesta_Design_Mobile.html','w').write(v.replace('<meta name="viewport" content="width=device-width, initial-scale=1">','<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover, maximum-scale=1">',1).replace('</head>',mcss+'</head>',1).replace("function fit(){","function fit(){return;",1))
