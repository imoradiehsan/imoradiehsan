# Qesta design pack

- `QESTA_SYSTEM_BRIEF.md`: system brief (read first)
- `Qesta_Design_Mobile.html`: full working mobile prototype, single file, open in a browser
- `Qesta_Design_Desktop.html`: same prototype with the desktop demo panel
- `source/app.html`: editable source (all screens, CSS, logic)
- `source/loans.js`: loan data (353 loans, 55 banks)
- `source/assets.js`: bank logos and images
- `source/build.py`: run inside `source/` to rebuild both HTML files after editing app.html

Tell Claude: "Do not redesign from scratch. Edit source/app.html, keep the existing design system, then run build.py."
